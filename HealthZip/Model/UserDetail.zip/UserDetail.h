//
//  UserDetail.h
//  HealthZip
//
//  Created by Tristate on 5/30/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDetail : NSObject


//----As per new design required only bellow fields data ----//
@property (nonatomic, strong) NSString *str_user_id;
@property (nonatomic, strong) NSString *str_first_name;
@property (nonatomic, strong) NSString *str_last_name;
@property (nonatomic, strong) NSString *str_email;
@property (nonatomic, strong) NSString *str_password;
@property (nonatomic, strong) NSString *str_is_verify;
@property (nonatomic, strong) NSString *str_profile_pic;


//-------------END------------------//

//@property (nonatomic, strong) NSString *str_user_name;
//@property (nonatomic, strong) NSString *str_gender;
//
//@property (nonatomic, strong) NSString *str_user_role;
//@property (nonatomic, strong) NSString *str_mobile_no;
//@property (nonatomic, strong) NSString *str_address;
//
//@property (nonatomic, strong) NSString *str_device_type;
//@property (nonatomic, strong) NSString *str_device_token;
//@property (nonatomic, strong) NSString *str_guid;
//@property (nonatomic, strong) NSString *str_created_date;

+(id)sharedInstance;
-(void)saveDetail:(UserDetail*)objDetail;
-(UserDetail*)getDetail;

@end
